/**
 * Created by 4535992 on 17/10/2015.
 */
package com.github.p4535992.extractor.hibernate;